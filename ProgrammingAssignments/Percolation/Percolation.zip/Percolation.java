/* Dane Osborne 6/30/2015
 *
 * This class creates a Percolation object
 * to simulate a 2 dimensional grid with 
 * either open or closed sites.
 * To execute: instantiate a Percolation object
 * that's dimension is N X N units.
*/

public class Percolation {
   private int rows;            // Variable for number of rows.
   
   private int columns;         // Variable for number of rows.
   
   private int dimen;           // Variable for dimension of array.
   
   private boolean[] siteOpen;  // An array to track open sites.
   
   private int seed;            // Variable for place in array
                                // of selected site in 2D grid.
   private int adjacentSeed;    // Variable for site next to the
                                // chosen site.
   private int N;               // Dimension of the two variable
                                // grid.  For example, 2 X 2 (N 
                                // =2).
   
   private WeightedQuickUnionUF wQU;
   
   // Constructor to create a Percolation instance
   // Input is the number of rows or columns.
   public Percolation(int N) {
      if (N <= 0) throw 
         new IllegalArgumentException("The number of rows and columns "
                                               + "must be greater than 0");
      this.N = N;
      setRows(N);
      setColumns(N);
      setDimen(getRows() * getColumns());
      siteOpen = new boolean[dimen];
      setAdjacentSeed(0);
      setSeed(0);
      
      wQU = new WeightedQuickUnionUF(dimen + 2);
   } // end constructor
   
   // Method to determine if a site is open or not.
   // Input is the row and column indices.
   public boolean isOpen(int i, int j) {
      validateIndices(i, j);
      return siteOpen[xyTo1D(i, j)];
   } // end isOpen method
   
   // Method to open chosen site and determine if cells adjacent
   // to chosen site are also open.  If so, they should be 
   // connected using the weightedQuickUnion object.
   public void open(int i, int j) {
      validateIndices(i, j);
      setSeed(xyTo1D(i, j));
      siteOpen[getSeed()] = true;
      
      // cell above
      if (i > 1 && isOpen(i - 1, j)) {
         setAdjacentSeed(xyTo1D(i - 1, j));
         wQU.union(getSeed(), getAdjacentSeed());
      }
      // cell below
      if (i < getRows() && isOpen(i + 1, j)) {
         setAdjacentSeed(xyTo1D(i + 1, j));
         wQU.union(getSeed(), getAdjacentSeed());
      }
      
      // cell to the right
      if (j < getColumns() && isOpen(i, j + 1)) {
         setAdjacentSeed(xyTo1D(i, j + 1));
         wQU.union(getSeed(), getAdjacentSeed());
      }
      
      // cell to the left
      if (j > 1 && isOpen(i, j - 1)) {
         setAdjacentSeed(xyTo1D(i, j - 1));
         wQU.union(getSeed(), getAdjacentSeed());
      }
      
      // if cell is in the first row connect it to the 
      // virtual site above the first row.
      if (i == 1) wQU.union(getDimen(), getSeed());
      
      // if cell to be opened is in the last row connect
      // it to the virtual site below the last row.
      if (i == getRows()) wQU.union(getDimen() + 1, getSeed());
      
   } // end open method
   
   // method to determine if the chosen site is connected to 
   // the first row.
   public boolean isFull(int i, int j) {
      validateIndices(i, j);
      if (isOpen(i, j)) {
         setSeed(xyTo1D(i, j));
         if (wQU.connected(getDimen(), getSeed()))
            return true;
      }
      return false;
   }
   
   // method to determine if the chosen site makes the system
   // percolate.  In other words, there is a connection from 
   // the first row to the last row.
   public boolean percolates() {
      if (wQU.connected(getDimen(), getDimen() + 1))
         return true;
      return false;
   }
   
   // private accessor methods
   private int getRows() {
      return rows;
   }
   
   private int getColumns() {
      return columns;
   }
   
   private int getDimen() {
      return dimen;
   }
   
   private int getAdjacentSeed() {
      return adjacentSeed;
   }
   
   private int getSeed() {
      return seed;
   }
   
   private void setRows(int i) {
      rows = i;
   }
   
   private void setColumns(int i) {
      columns = i;
   }
   
   private void setDimen(int i) {
      dimen = i;
   }
   
   private void setAdjacentSeed(int i) {
      adjacentSeed = i;
   }
   
   private void setSeed(int i) {
      seed = i;
   }
   
   // This method converts the 2D position to the position
   // of the site in the 1D array
   private int xyTo1D(int i, int j) {
      int arrayPosition = N * (i - 1) + (j - 1);
      return arrayPosition;
   }
   
   
   // Method to determine that the site chosen is a valid 
   // site or it does exist.
   private void validateIndices(int i, int j) {
      if (i < 1 || i > N) throw
         new IndexOutOfBoundsException("row index i out of bounds");
      if (j < 1 || j > N) throw
         new IndexOutOfBoundsException("column index j out of bounds");
   }
   
   // Test Client
   public static void main(String[] args) {
      Percolation perc = new Percolation(4);
      perc.open(1, 1);
      perc.open(1, 2);
      perc.open(1, 3);
      boolean connected = perc.wQU.connected(0, 2);
      StdOut.println(""+ connected);
   }
}